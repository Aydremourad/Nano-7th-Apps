# Setting up a stock nano

The app installer needs untethered homebrew firmware **first**. The original 2012 nano and the 2015 refresh use different patched IPSWs, even though both can say A1446 and 1.1.2.

## 1. Identify which nano you have

- The 2015 revision came in **gold**; a gold 7G is 2015. Many other colors overlap, so check the purchase year and hardware history if possible.
- If you can't confirm the revision, **stop**. Don't guess a firmware file from the A1446 model number alone.

## 2. Back up first

Copy your music, playlists and other files off the nano before making changes. Keep a separate full-device backup if you have the tools to make one. A normal file copy does not back up the firmware. If the device bricks, neither backup is a guarantee of recovery.

## 3. Download the right patched firmware

Run `Get-Firmware.command` using Terminal:

```bash
bash ~/Downloads/Nano7-Mac-Apps/Get-Firmware.command
```

Choose **2012** or **2015**. The helper downloads the matching `ipod_sun_untethered` v1.0 IPSW from GitHub and checks its published SHA-256 before keeping it in `~/Downloads/Nano7-Firmware`. It doesn't connect to or write to the nano. You can also get the firmware directly from the [upstream release](https://github.com/nfzerox/ipod_sun_untethered/releases/tag/1.0).

## 4. Install firmware with the appropriate method

The [NanoApps instructions](https://github.com/nfzerox/NanoApps#getting-started) document restoring the matching IPSW with **iTunes on Windows**, then installing the full NanoApps set with **Linux**. That is their published route.

On Mac, Finder/iTunes supports holding **Option** while clicking **Check for Update** to choose an IPSW, as described by [ipod_theme](https://github.com/nfzerox/ipod_theme). However, this specific modified `ipod_sun_untethered` firmware has **not** been verified as an end-to-end Mac-only install in this kit. Do not treat it as guaranteed or press Restore casually—restoring erases your content. Wrong firmware or failed flashing can permanently brick a nano.

If you need device flashing/recovery tools, [LeUnBrIck](https://github.com/LycanLD/LeUnBrIck) lists macOS support for 2012/2015 nano 7G. It is a separate experimental project, not something this kit has tested. Follow its instructions instead of mixing flash commands.

**After patching:** The SCSI channel in `ipod_sun_untethered` can cause rebooting when attached to Finder/iTunes. If that occurs, disconnect from Finder and use **Disk Mode** to access the mounted files: restart by holding Home + Sleep/Wake, then as the screen goes black hold both volume buttons until Disk Mode appears. The official NanoApps guide explains this, too.

## 5. Install the four apps

When compatible homebrew firmware is already running and the nano mounts with its `iPod_Control` folder visible:

```bash
bash ~/Downloads/Nano7-Mac-Apps/Start.command
```

Choose **1** (inspect), then **5** (offline check), then **2** (install) after reading the compatibility warning. Safely eject and open Music, then return Home.

**2012 note:** The included four-app A/B loader came from a working 2015 nano and **has not been hardware-tested on the 2012 refresh**. Do not install it on a 2012 nano without a recovery plan. For the most established app-install method on 2012, follow [NanoApps](https://github.com/nfzerox/NanoApps) on Linux instead.

## If you want the full upstream app collection

This kit provides just Calculator, Contacts, Chess and Golf. For the full set, use the [NanoApps Linux installer](https://github.com/nfzerox/NanoApps) in place of these A/B loader files; don't mix them.

## Recovery

If the nano will not boot, stop experimenting with firmware files. Start with the [upstream recovery notes](https://github.com/olievans123/nano7-untethered/blob/main/untether/docs/RECOVERY.md) or [LeUnBrIck](https://github.com/LycanLD/LeUnBrIck). Neither guarantees recovery from every failure.
