# Credits and licenses

This app kit uses projects by other contributors. It isn't affiliated with Apple.

- [NanoApps](https://github.com/nfzerox/NanoApps) — app framework and original app sources; MIT license, copyright 2026 nfzerox.
- [ipod_sun_untethered](https://github.com/nfzerox/ipod_sun_untethered) — patched firmware tool and releases; GPL-3.0. Firmware is **not included** in this ZIP; the download helper obtains the matching upstream release on demand.
- [nano7-untethered](https://github.com/olievans123/nano7-untethered) — A/B resident loader lineage and integration; review its CREDITS.md and upstream source.
- [wInd3x](https://github.com/freemyipod/wInd3x) — flashing/exploit tools; GPL-2.0, **not bundled**.

These binaries are provided with their upstream attribution. Source and original license texts are available in the linked projects. Redistributions should preserve the copyright and license notices and comply with any corresponding-source obligations, especially for GPL components.

**MIT license notice (NanoApps):**

Copyright (c) 2026 nfzerox

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
