#!/usr/bin/env python3
"""Download, checksum-check and stage an official upstream nano 7G patched IPSW.
No writes to USB devices. No install or flash operation.
"""
from pathlib import Path
import hashlib,sys,urllib.request,os

SOURCE='https://github.com/nfzerox/ipod_sun_untethered/releases/download/1.0/'
BUILDS={
  '2012':('iPod_1.1.2_39A10023_2012_ipod_sun_untethered.ipsw','cbf1ae355202b9818bcf0a7745e8ea3d99ef6cc1c7a16722e418158ae53892a4',193270874),
  '2015':('iPod_1.1.2_39A10023_2015_ipod_sun_untethered.ipsw','33986f756e3423048bbcad85a2a42fcbda78f11bc0f030c8fbd41116b2785c67',193270874)
}

def sha256(path):
  h=hashlib.sha256()
  with path.open('rb') as f:
    for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
  return h.hexdigest()

def main():
  if len(sys.argv)>2 or (len(sys.argv)==2 and sys.argv[1] not in BUILDS):
    print('Usage: python3 firmware_fetch.py [2012|2015]');return 1
  print('iPod nano 7G: firmware download')
  print('Both revisions may say A1446. Pick the actual hardware revision.')
  print('This only downloads and checks the file. It does NOT install or flash firmware.')
  year=sys.argv[1] if len(sys.argv)==2 else input('Enter 2012 or 2015 (other cancels): ').strip()
  if year not in BUILDS:return 1
  name,expected,size=BUILDS[year]
  folder=Path.home()/'Downloads'/'Nano7-Firmware'; folder.mkdir(parents=True,exist_ok=True)
  target=folder/name
  if target.is_symlink() or folder.is_symlink():raise RuntimeError('Symlink destination: refusing')
  if target.exists() and target.stat().st_size==size and sha256(target)==expected:
    print('Already downloaded and verified:',target);return 0
  url=SOURCE+name
  print('Source:',url)
  print('Save to:',target)
  if input('Type DOWNLOAD to continue: ').strip()!='DOWNLOAD':return 1
  temp=target.with_name(target.name+'.partial')
  if temp.exists() or temp.is_symlink():raise RuntimeError('A partial download already exists. Remove it manually after checking it.')
  try:
    req=urllib.request.Request(url,headers={'User-Agent':'Nano7-Mac-Apps/1.1'})
    with urllib.request.urlopen(req,timeout=40) as res,temp.open('xb') as f:
      total=0
      while True:
        chunk=res.read(1024*1024)
        if not chunk:break
        total+=len(chunk)
        if total>size:raise RuntimeError('Download exceeded expected size')
        f.write(chunk)
        if total%(20*1024*1024)<len(chunk):print(f'  {total//1048576} MiB downloaded')
      f.flush();os.fsync(f.fileno())
    if temp.stat().st_size!=size or sha256(temp)!=expected:raise RuntimeError('File checksum/size mismatch. Do not use.')
    os.replace(temp,target)
  except BaseException:
    try:temp.unlink(missing_ok=True)
    except OSError:pass
    raise
  print('VERIFIED SHA-256:',expected)
  print('File:',target)
  print('Read SETUP.md for installing matching firmware and backing up before restoring.')
  return 0
if __name__=='__main__':
  try:sys.exit(main())
  except Exception as e:print('STOP:',e,file=sys.stderr);sys.exit(1)
