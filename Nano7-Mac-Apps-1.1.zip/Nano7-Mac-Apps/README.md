# Nano 7th Apps (Mac)

Calculator, Contacts, Chess and Golf for the iPod nano 7G.

## Install

1. Unzip the download into **Downloads**.
2. Connect your nano to the Mac (only one iPod at a time).
3. Open Terminal and run:

```bash
bash ~/Downloads/Nano7-Mac-Apps/Start.command
```

Choose **1** to check the nano, **5** to check the app files and **2** to install. The installer backs up what it replaces to `~/Desktop/Nano7-App-Backups` and can restore those files using option **4** if the nano still mounts. It needs Python 3 (`python3 --version`).

**Stock nano?** Read [SETUP.md](SETUP.md) first. You can use `Get-Firmware.command` to download and verify the **2012 or 2015** patched firmware. It **does not flash firmware**.

**Compatibility:** These app files and resident loader came from a working **2015 gold nano**. This exact loader has **not** been tested on a 2012 nano. Don't install it on an unknown firmware build or a 2012 unit without knowing your recovery options. This kit was checked offline; it has not been validated end-to-end on every nano.

The Mac app installer is for **already-compatible untethered firmware**. Installing firmware on a stock device is a separate step. [SETUP.md](SETUP.md) explains both revisions, firmware downloads, alternative tools and recovery links. No Apple firmware is bundled.

[Credits and licenses](LICENSES.md)
